
//регистрация пользователей
//сделать post запрос в бд для создание нового пользователя
export const newUser = async (dispatch, data, navigation) => {
    try{
        dispatch({type: 'log_onfetch'})
        await fetch(`http://localhost:3900/newregister`, {
        method: 'POST',
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
      })
        .then(res => res.json())
        .then(res => {
          // console.log('createPost_success')
          if (res.ok && typeof res.userId == 'string') {

            dispatch({ type: 'createUser', userId: res.userId, userName: res.name, loading: false, success: true })
            navigation(`/user/${res.userId}`)
          }else{//при не успешной попытки перенаправляет заново на страницу регистрации с сообщением
            dispatch({ type: 'failCreate', answer: res.answer, trylog: false})
            navigation('/register')
          }
        })
    
    }
    catch (error){
        dispatch({type: 'createError', userId: '', userName: '', loading: false, success: false, errMsg: 'Ошибка при создании пользователя'})
    }
}

//вход пользователя
export const logUser = async (dispatch, data, navigation) => {
    try{
        await dispatch({type: 'log_onfetch'})
        await fetch('http://localhost:3900/login/new', {
        method: 'POST',
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
      })
        .then(res => res.json())
        .then(res => {
          
          if (res.ok && typeof res.userId == 'string') {

            dispatch({ type: 'logUser', userId: res.userId, userName: res.name, loading: false, success: true })
            navigation(`/user/${res.userId}`)
          }else{
            //если пользователь ввел не правильные данные
            dispatch({ type: 'failLog', answer: res.answer, trylog: false})
            navigation('/login')
          }
        })
    
    }
    catch (error){
        dispatch({type: 'logError', userId: '', userName: '', loading: false, success: false, errMsg: 'Ошибка при создании пользователя'})
    }
}





