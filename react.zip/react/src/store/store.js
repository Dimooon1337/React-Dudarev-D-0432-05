import { combineReducers, createStore, applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import { postsReducer } from './reducers/postsReducer'
import { userLogsReducer } from './reducers/userLogsReducer'

const rootReducer = combineReducers({
  posts: postsReducer,
  userLogs: userLogsReducer,
})

export const store = createStore(rootReducer, applyMiddleware(thunk) )
//содкржит редюсеры к которым мы будем обращаться