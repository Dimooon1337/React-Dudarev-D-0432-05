const defaultState = {
    loading: true,
    success: false,
    trylog: true, //попытка входа пользователя, для уведомления пользователя о неправельности введённых данных
    errMsg: '',
    userId: '',
    userName: ''   
}

export const userLogsReducer = (state = defaultState, action) =>{
    console.log('action from  userLogsReducer:', action)
    switch(action.type){
        case 'log_onfetch': //сбрасывает store 
            return{...state, userId: '', userName: '', trylog: true}
        case 'createUser':
            return{...state, ...action}
        case 'failCreate':
            return {...state, ...action}
        case 'logUser':
            return{...state, ...action}
        case 'failLog':
            return{...state, ...action}
        case 'createError':
            return{...state, ...action}
        case 'logError':
            return{...state, ...action}
        default:
            return{...state}
    }
}