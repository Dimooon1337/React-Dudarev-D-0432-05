// MEAN - MongoDB / ExpressJS / Angular / NodeJS

// MERN -  MongoDB / ExpressJS / React / NodeJS