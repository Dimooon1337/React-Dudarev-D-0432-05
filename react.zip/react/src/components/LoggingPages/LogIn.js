import { Link, useNavigate } from 'react-router-dom'
import { Button,Form, Input, Typography  } from 'antd';
import { LockOutlined, UserOutlined } from '@ant-design/icons';
import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { logUser } from '../../store/actions/logsActions';

export const LogIn = () => {
    const { Text } = Typography;

    const navigation = useNavigate();
    const dispatch = useDispatch();
    const { userId, trylog } = useSelector((state) => state.userLogs)
    //данные который заполнил пользователь
    const [logData, setLogData] = useState({
        login: '',
        password: '',
      })
    

    //метод в actions/logsActions для редюсера        
      const newLoginMethod = async () => {
        await logUser(dispatch, logData, navigation)
      }

      const checkStore = () => {
        console.log('айди пользователя в store: ', userId)
      }
      
    
    
    const onFinish = (values) => {
        console.log('Received values of form: ', values);
      };

    return(
        <div>
            <Form
                name="normal_login"
                className="login-form"
                
                initialValues={{
                    remember: true,
                }}
                onFinish={onFinish}
                >
                <Form.Item
                    name="login"
                    rules={[
                    {
                        required: true,
                        message: 'Please input your Login!',
                    },
                    ]}
                >
                    <Input prefix={<UserOutlined className="site-form-item-icon" />} placeholder="Login"
                    value={logData.login} onChange={(e) => setLogData({ ...logData, login: e.target.value })} />
                </Form.Item>
                <Form.Item
                    name="password"
                    rules={[
                    {
                        required: true,
                        message: 'Please input your Password!',
                    },
                    ]}
                >
                    <Input
                    prefix={<LockOutlined className="site-form-item-icon" />}
                    type="password"
                    placeholder="Password"
                    value={logData.password} onChange={(e) => setLogData({ ...logData, password: e.target.value })}
                    />
                </Form.Item>
                {!trylog && (() => {
                return (
                    <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
                        <Text keyboard>Пароли не совпадают, попробуйте снова</Text>
                    </Form.Item>
                        )
                    })()}
                <Form.Item>
                    <Button type="primary" htmlType="submit" className="login-form-button" onClick={() => newLoginMethod()}>
                    Log in
                    </Button>
                    Or < Link to= "/register">register now!</Link>
                </Form.Item>
                </Form>
        </div>
    )
}