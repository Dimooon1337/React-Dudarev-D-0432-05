import { Button, Form, Input, Typography } from 'antd';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { newUser } from '../../store/actions/logsActions';


export const SignUp = () => {
    
    const { Text } = Typography;

    const dispatch = useDispatch()
    const navigation = useNavigate();
    const { trylog } = useSelector((state) => state.userLogs)
    
    //состояние для регистрации 
    const [regData, setRegData] = useState({
        name: '',
        fullname: '',
        email: '',
        login: '',
        password: '',
        confirmPassword: ''
      })

      const createUserMethod = async () =>{
        console.log("reg DATA^ ", regData)
        if (regData.password === regData.confirmPassword){
            await newUser(dispatch, regData, navigation)
        }else {
            dispatch({type: 'failCreate', trylog: false})  
            navigation('/register')
        }
      }



    const onFinish = (values) => {
        console.log('Success:', values);
      };
      const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
      };

    return(
        <div>
                    <Form
            name="basic"
            labelCol={{
            span: 8,
            }}
            wrapperCol={{
            span: 16,
            }}
            style={{
            maxWidth: 600,
            }}
            initialValues={{
            remember: true,
            }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
        >
            <Form.Item
            label="Username"
            name="username"
            rules={[
                {
                required: true,
                message: 'Please input your username!',
                },
            ]}
            >
            <Input value={regData.login} onChange={(e) => setRegData({ ...regData, name: e.target.value })} />
            </Form.Item>

            <Form.Item
            label="Full name"
            name="fullName"
            rules={[
                {
                required: true,
                message: 'Please input your full name!',
                },
            ]}
            >
            <Input value={regData.fullname} onChange={(e) => setRegData({ ...regData, fullname: e.target.value })} />
            </Form.Item>

            <Form.Item
            label="Email"
            name="email"
            rules={[
                {
                required: true,
                message: 'Please input your email!',
                },
            ]}
            >
            <Input value={regData.email} onChange={(e) => setRegData({ ...regData, email: e.target.value })} />
            </Form.Item>

            <Form.Item
            label="Login"
            name="login"
            rules={[
                {
                required: true,
                message: 'Please input your username!',
                },
            ]}
            >
            <Input value={regData.name} onChange={(e) => setRegData({ ...regData, login: e.target.value })} />
            </Form.Item>

            <Form.Item
            label="Password"
            name="password"
            rules={[
                {
                required: true,
                message: 'Please input your password!',
                },
            ]}
            >
            <Input.Password value={regData.password} onChange={(e) => setRegData({ ...regData, password: e.target.value })}/>
            </Form.Item>

            <Form.Item
            label="Confirm password"
            name="confirmpassword"
            rules={[
                {
                required: true,
                message: 'Please input your password!',
                },
            ]}
            >
            <Input.Password value={regData.confirmPassword} onChange={(e) => setRegData({ ...regData, confirmPassword: e.target.value })}/>
            </Form.Item>

            <Form.Item
            wrapperCol={{
                offset: 8,
                span: 16,
            }}
            >
            <Button type="primary" htmlType="submit" onClick={() => createUserMethod()}>
                SignUp
            </Button >
            </Form.Item>

            
            {!trylog && (() => {
                return (
                    <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
                        <Text keyboard>Пароли не совпадают, попробуйте снова</Text>
                    </Form.Item>
                )
            })()}
        </Form>
        </div>
    )
}